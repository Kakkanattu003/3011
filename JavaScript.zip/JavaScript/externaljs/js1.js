function alertexternal(){
    alert("External alert")
}
function confirmexternal(){
    if(confirm("Pakka na bhai?(external)")){
        alert("Toh phir done(external)")
    }
    else{
        alert("Thik hai no problem(external)")
    }
}
function promptexternal(){
    var fn=prompt("Naam de apnaa(external)");
    var ln=prompt("Surname kaun dega(external)");
    if(confirm("Tera naam "+fn+" "+ln+" hai?(external)")){
        alert("Thik hai phir(external)")
    }
    else{
        alert("Toh phir kya hai?!(external)")
    }
}